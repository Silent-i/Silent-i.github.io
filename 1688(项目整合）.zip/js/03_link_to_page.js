// 打开 张耀 01 的页面
$(".link_to_01_main").click(function() {
	window.open("01_main.html")
});
$(".link_to_01_sub").click(function() {
	window.open("01_sub.html")
});

// 打开业明 02 的页面
$(".link_to_02_main").click(function() {
	console.log("1111");
	window.open("02_main.html");
});
$(".link_to_02_sub").click(function() {
	window.open("02_sub.html");
});

// 打开福子 03 的页面
$(".link_to_03_main").click(function() {
	window.open("../index.html");
});
$(".link_to_03_sub").click(function() {
	window.open("03_sub.html");
});
// 打开腾运 04 的页面
$(".link_to_04_main").click(function() {
	window.open("04_main.html");
});
$(".link_to_04_sub").click(function() {
	window.open("04_sub.html");
});

// 打开李林 05 的页面
$(".link_to_05_main").click(function() {
	window.open("05_countryshop.html");
});
$(".link_to_05_sub").click(function() {
	window.open("05_kjns.html");
});
