// 打开 张耀 01 的页面
$(".link_to_01_main").click(function() {
	window.open("page/01_main.html")
});
$(".link_to_01_sub").click(function() {
	window.open("page/01_sub.html")
});
// 打开 业明 02 的页面
$(".link_to_02_main").click(function() {
	window.open("page/02_main.html");
});
$(".link_to_02_sub").click(function() {
	window.open("page/02_sub.html");
});
// 打开 福子 03 的页面
$(".link_to_03_main").click(function() {
	window.open("index.html");
});
$(".link_to_03_sub").click(function() {
	window.open("page/03_sub.html");
});
// 打开 腾运 04 的页面
$(".link_to_04_main").click(function() {
	window.open("page/04_main.html");
});
$(".link_to_04_sub").click(function() {
	window.open("page/04_sub.html");
});

// 打开 李林 05 的页面
$(".link_to_05_main").click(function() {
	window.open("page/05_countryshop.html");
});
$(".link_to_05_sub").click(function() {
	window.open("page/05_kjns.html");
});

// 打开 梦涛 06 的页面
$(".link_to_06_main").click(function() {
	window.open("page/06_main.html");
});
$(".link_to_06_sub").click(function() {
	window.open("page/06_sub.html");
});
