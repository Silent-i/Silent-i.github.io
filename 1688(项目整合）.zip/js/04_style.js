
//04.html的js
//two_1的隐藏框
$(function(){
	$(".two_1_left>a>img").mouseover(function(){
		$(".two_1_left_list1").show();
		$(document).ready(function(){
		$(".two_1_left_list1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_1_right_list4-1>a>span").mouseover(function(){
		$(".two_1_left_list4-1-1").show();
		$(document).ready(function(){
		$(".two_1_left_list4-1-1").delay(1000).hide(0);
	});
	})
})
//two_2

$(function(){
	$(".two_2_left>a>img").mouseover(function(){
		console.log("1");
		$(".two_2_left_list1").show();
		$(document).ready(function(){
		$(".two_2_left_list1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_2_right_list4-1>a>span").mouseover(function(){
		console.log("2");
		$(".two_2_left_list4-1-1").show();
		$(document).ready(function(){
		$(".two_2_left_list4-1-1").delay(1000).hide(0);
	});
	})
})
//two_3
$(function(){
	$(".two_3_left>a>img").mouseover(function(){
		console.log("3");
		$(".two_3_left_list1").show();
		$(document).ready(function(){
		$(".two_3_left_list1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_3_right_list4-1>a>span").mouseover(function(){
		$(".two_3_left_list4-1-1").show();
		$(document).ready(function(){
		$(".two_3_left_list4-1-1").delay(1000).hide(0);
	});
	})
})
//two_4
$(function(){
	$(".two_4_left>a>img").mouseover(function(){
		$(".two_4_left_list1").show();
		$(document).ready(function(){
		$(".two_4_left_list1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_4_right_list4-1>a>span").mouseover(function(){
		$(".two_4_left_list4-1-1").show();
		$(document).ready(function(){
		$(".two_4_left_list4-1-1").delay(1000).hide(0);
	});
	})
})








//服务能力隐藏div
//two_1
$(function(){
	$(".two_1_right_list4-1>a>img").mouseover(function(){
		$(".two_1_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_1_right_list4-1-1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_1_right_list4-1>a>span").mouseover(function(){
		$(".two_1_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_1_right_list4-1-1").delay(1000).hide(0);
	});
	})
})
//two_2
$(function(){
	$(".two_2_right_list4-1>a>img").mouseover(function(){
		$(".two_2_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_2_right_list4-1-1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_2_right_list4-1>a>span").mouseover(function(){
		$(".two_2_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_2_right_list4-1-1").delay(1000).hide(0);
	});
	})
})

//two_3
$(function(){
	$(".two_3_right_list4-1>a>img").mouseover(function(){
		$(".two_3_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_3_right_list4-1-1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_3_right_list4-1>a>span").mouseover(function(){
		$(".two_3_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_3_right_list4-1-1").delay(1000).hide(0);
	});
	})
})
//two_4
$(function(){
	$(".two_4_right_list4-1>a>img").mouseover(function(){
		$(".two_4_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_4_right_list4-1-1").delay(1000).hide(0);
	});
	})
})

$(function(){
	$(".two_4_right_list4-1>a>span").mouseover(function(){
		$(".two_4_right_list4-1-1").show();
		$(document).ready(function(){
		$(".two_4_right_list4-1-1").delay(1000).hide(0);
	});
	})
})

